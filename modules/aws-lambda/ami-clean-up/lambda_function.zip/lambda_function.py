import boto3

# Initialize EC2 client
ec2 = boto3.client('ec2')

def lambda_handler(event, context):
    try:
        # Fetch AMIs with the name pattern 'jenkins-backup-*'
        response = ec2.describe_images(
            Filters=[
                {'Name': 'name', 'Values': ['jenkins-backup-*']}
            ],
            Owners=['self']  # Limit to AMIs owned by your account
        )

        # Extract and sort AMIs by creation date (newest first)
        images = response['Images']
        images.sort(key=lambda x: x['CreationDate'], reverse=True)

        # Check if there are more than 2 AMIs
        if len(images) <= 2:
            print("No AMIs to delete. Only 2 or fewer AMIs are present.")
            return {
                "statusCode": 200,
                "body": "No AMIs to delete. Cleanup skipped."
            }

        # Retain only the latest 2 AMIs
        images_to_delete = images[2:]  # Keep the first two, delete the rest
        deleted_amis = []  # List to store deleted AMI IDs

        for image in images_to_delete:
            ami_id = image['ImageId']
            ami_name = image['Name']
            print(f"Deregistering AMI: {ami_id} (Name: {ami_name})")
            deleted_amis.append(ami_id)

            # Deregister the AMI
            ec2.deregister_image(ImageId=ami_id)

            # Delete associated snapshots
            for block_device in image.get('BlockDeviceMappings', []):
                if 'Ebs' in block_device:
                    snapshot_id = block_device['Ebs']['SnapshotId']
                    print(f"Deleting Snapshot: {snapshot_id}")
                    ec2.delete_snapshot(SnapshotId=snapshot_id)

        # Display the list of deleted AMIs
        print(f"Deleted AMIs: {', '.join(deleted_amis)}")

        return {
            "statusCode": 200,
            "body": f"Cleanup complete. Deleted AMIs: {', '.join(deleted_amis)}"
        }

    except Exception as e:
        print(f"Error: {e}")
        return {
            "statusCode": 500,
            "body": f"Error: {e}"
        }
